import {createContext} from "react"


export const Driver = createContext()
export const Truck = createContext()