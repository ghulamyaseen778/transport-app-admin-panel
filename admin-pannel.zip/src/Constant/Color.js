export const COLOR = {
    color2:"#F07F21"
}